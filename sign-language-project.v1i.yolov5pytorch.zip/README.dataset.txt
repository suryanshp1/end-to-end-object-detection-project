# sign-language-project > 2025-01-26 12:20pm
https://universe.roboflow.com/test-dktp4/sign-language-project-klcp4

Provided by a Roboflow user
License: CC BY 4.0

